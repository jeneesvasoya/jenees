﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B15
{
    class jd
    {
        public string name = "jdvasoya";
        public int id = 50;
    }
}
