﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//I1.Create program to replace specific word from string

namespace I1
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "hello sir";
            Console.WriteLine(name.Replace('e','J'));
            Console.Read();
        }
    }
}
