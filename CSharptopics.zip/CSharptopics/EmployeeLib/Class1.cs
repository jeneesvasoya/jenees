﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class Employee
    {
        protected internal void display()
        {
            Console.WriteLine("Calling display from EmployeeLib");
        }
    }
}
