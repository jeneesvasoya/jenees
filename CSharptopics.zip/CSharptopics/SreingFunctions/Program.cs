﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SreingFunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "  Learning Programing in C#  ";
            //Console.WriteLine(name.Contains("inhg"));
            //Console.WriteLine(name.StartsWith("Le"));
            //Console.WriteLine(name.EndsWith("#"));
            //Console.WriteLine(name.IndexOf("ing"));
            //Console.WriteLine(name.Insert(9, "Programing "));
            //Console.WriteLine(name.PadRight(20,'*'));
            //Console.WriteLine(name.Remove(8,11));
            //Console.WriteLine(name.Replace("ing","T"));
            //Console.WriteLine(name.Substring(9,10));
            //Console.WriteLine(name.ToUpper());
            Console.WriteLine(name.Trim());

            Console.Read();
        }
    }
}
